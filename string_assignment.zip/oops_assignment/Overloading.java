package mypkg;

public class Overloading {
	int area(int d1,int d2) {
		return (d1*d2)/2;
	}
	int area(int radi) {
		int val=(int)3.1415*radi*radi;
		return val;
	}
	float area(float l,float b) {
		return l*b;
	}
	long area(long side) {
		return side*side;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Overloading o=new Overloading();
		System.out.println("Area of Rectangle is "+ o.area(10.2f,1.0f));
		System.out.println("Area of Square is "+ o.area(100l));
		System.out.println("Area of Circle is "+o.area(20));
		//area(100,2);
	}

}
