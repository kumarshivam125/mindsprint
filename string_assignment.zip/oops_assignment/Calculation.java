package mypkg;

public class Calculation {
	
	void calculate(int a,int b) {
		System.out.println("Divide "+a/b);
	}
	void calculate(int a,float b) {
		float ans=a+b;
		System.out.println("Add "+ans);
	}
	void calculate(float a,float b) {
		float ans=a-b;
		System.out.println("Subtract "+ans );
	}
	void calculate(double a,double b) {
		System.out.println("Multiply"+a*b);
	}
	boolean isEven(int a) {
		return a%2==0;
	}
	
	public static void main(String[] args) {
		Calculation c=new Calculation();
		c.calculate(10,2);
		c.calculate(10,2.1f);
		c.calculate(10.0f,2.1f);
		c.calculate(10.0,2.0);
		
		String msg=c.isEven(11)?"Even":"Odd";
		System.out.println(msg);
		
	}

}
