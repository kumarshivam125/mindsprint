package mypkg;

class Bank{
	void display() {
		System.out.println("Display from Bank");
	}
}
class Axis extends Bank{
	void display() {
		System.out.println("Display from AXIS");
	}
}
class ICICI extends Bank{
	void display() {
		System.out.println("Display from ICICI");
	}
}
public class Polymorphism {
	public static void main(String[] args) {
		Bank b;
		
		b=new Axis();
		b.display();
		
		b=new ICICI();
		b.display();
		
	}
}
