package mypkg;

//Multiple Intertance is not in JAVA 
class Product{
	int id;
	String name;
	Product(){}
	Product(int id,String name){
		this.id=id;
		this.name=name;
	}
	void display() {
		System.out.println("Product "+id+name);
	}
}
class A extends Product{
	int count;
	String category;
	A(int id,String name,int count,String category){
		super(id,name);
		this.count=count;
		this.category=category;
	}
	void display() {
		System.out.println("CLASS A "+id+name+count+category);
	}
}
class B extends Product{
	int count;
	String category;
	B(int id,String name,int count,String category){
		super(id,name);
		this.count=count;
		this.category=category;
	}
	void display() {
		System.out.println("CLASS B "+id+name+count+category);
	}
}
class C extends Product{
	int count;
	String category;
	void display() {
		System.out.println("CLASS C "+id+name+count+category);
	}
}

class subA extends A{
	int price;
	subA(int id,String name,int count,String category,int price){
		super(id,name,count,category);
		this.price=price;
	}
	void display() {
		int total_price=price*count;
		System.out.println("CLASS SUB-A "+id+name+category+total_price);
	}
}
class subB extends B{
	int price;
	subB(int id,String name,int count,String category,int price){
		super(id,name,count,category);
		this.price=price;
	}
	void display() {
		int total_price=price*count;
		System.out.println("CLASS SUB-B "+id+name+category+total_price);
	}
}
public class Inheritance {
	public static void main(String args[]) {
		subA obj=new subA(101,"Coffe",10,"Grocery",2);
		obj.display();
		
		
	}
}
