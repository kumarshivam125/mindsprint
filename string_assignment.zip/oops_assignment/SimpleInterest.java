package mypkg;

public class SimpleInterest {
	void display() {
		System.out.println("Calling Display");
	}
	double calculateSI(int p,double r,int t) {
		display();
		return (p*r*t)/100+p ;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimpleInterest s1=new SimpleInterest();
		
		System.out.println("Total Aoumt-"+s1.calculateSI(1000, 4, 10));
		
	}

}
