package mypkg;


interface A1{
	void fun1();
	void fun2();
	int salary=100; //Variable in interface is Static & final by default
}
interface B1 {
	int salary=500;
	void fun3();
}
class Demo implements A1,B1{
	public void fun1() {
		System.out.println("FUN 1");
	}
	public void fun2() {
		System.out.println("FUN 2");
	}
	public void fun3() {
		System.out.println("FUN 3");
	}
}
public class InterfaceDemo {
	public static void main(String[] args) {
		Demo d=new Demo();
		d.fun1();
		d.fun2();
		d.fun3();
//		System.out.println(d.salary);
		System.out.println(A1.salary);
		System.out.println(B1.salary);
		
	}

}
