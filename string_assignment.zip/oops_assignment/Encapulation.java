package mypkg;

public class Encapulation {
	private String name;
	private int empId;
	private float salary;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}

	public static void main(String args[]) {
		Encapulation e=new Encapulation();
		e.setEmpId(10);
		System.out.println(e.getEmpId());
	}
	
}
