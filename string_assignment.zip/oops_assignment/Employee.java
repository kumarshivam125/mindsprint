package mypkg;

public class Employee {
	String name;
	int age;
	Employee(String name,int age){
		this.age=age;
		this.name=name;
	}
	void printEmployee() {
		System.out.println();
	}
	public static void main(String[] args) {
		Employee e=new Employee("Shivam",21);
		
	}

}
