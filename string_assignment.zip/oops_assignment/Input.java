package mypkg;

import java.io.*;
import java.util.*;
public class Input {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		System.out.println("Entered Name is-"+str);
	}

}
