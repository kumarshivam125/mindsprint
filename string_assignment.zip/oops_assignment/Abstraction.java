package mypkg;

//(Parent) MNC ---> 2 abstract methods(leaves,holidays) + 1 constructor + 1 normal method
//
//Mindsprint(child of MNC) ----> make leave as abstract and other method holidays you can give the method body
// 
//Hello (child of Mindsprint) ----> here implement all the abstarct methods + 1 create normal method also
// 
//Main class ---> call all the methods of all classes using the dynamic polymorphism

abstract class MNC{
	abstract void leaves();
	abstract void holidays();
//	MNC(){
//		System.out.println("Calling CTR");
//	}
}
abstract class Mindsprint extends MNC{
	abstract void leaves();
	void holidays() {
		System.out.println("Holidays ");
	}
}
class Hello extends Mindsprint{
	void leaves() {
		System.out.println("Leaves");
	}
	void normal() {
		System.out.println("Normal method ");
	}
}

public class Abstraction {
	public static void main(String[] args) {
		Hello hel;
		hel=new Hello();
		
		hel.leaves();
		hel.holidays();
		
		hel.normal();
		
	}

}
