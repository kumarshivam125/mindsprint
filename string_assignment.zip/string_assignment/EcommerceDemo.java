package stringPkg;

class Ecommerce{
	int id,price;
	String name;
	static int discount=5;
	Ecommerce(int id1,int price1,String name1){
		id=id1;
		price=price1;
		name=name1;
//		discount=discount1; STATIC We should not to change in CTR 
	}
	void original() {
		System.out.println("Original Discounted Price-"+price*0.95);
	}
	void print() {
		System.out.println(name+" "+price+" Discounted "+price*(100-discount)/100);
	}
}

public class EcommerceDemo {

	public static void main(String[] args) {
		Ecommerce elec1=new Ecommerce(1,100,"P1");
		elec1.print();
		Ecommerce food1=new Ecommerce(2,100,"P2");
		food1.print();
		
		System.out.println("\n---After Discount---\n");
		
		Ecommerce.discount=10;
		elec1.print();
		
		Ecommerce.discount=30;
		food1.print();
		
	}

}
