package stringPkg;

public class String3 {

	public static void main(String[] args) {
//		StringBuffer-->More thread Safe---- Used in THREADING
//		StringBuilder 
		
		StringBuffer sb=new StringBuffer("Shivam");
		sb.append(" Kumar");
		
		System.out.println(sb);
		StringBuilder s1=new StringBuilder("Kaustav");
		System.out.println(s1.charAt(0));
	}

}
