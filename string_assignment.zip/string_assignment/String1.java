package stringPkg;

public class String1 {
//	== will check the reference 
//	equals will check the content 
	
	public static void main(String[] args) {
		String s1="Java";//This will be in String pool
		String s2=new String("Java"); //This will be in heap
		
		String s3="Java";
		String s4=new String("Java");
		
		System.out.println(s1==s2); 
		
		System.out.println(s1==s3);
		System.out.println(s2==s4);
		
	}

}
