package mypkg;
import java.util.*;
public class LinkedHashMapDemo2 {
//	Assignment 6:
//		Create object of LinkedHashmap of 10 countries of your choice( countrycode = key and countryname= value)
//		do following operations:
//		- fetch all the map keys
//		- fetch all the map values
//		- check if the value("India") exists or not
//		- check if the key(45) exists or not
//		- remove 1 country
//		 
//		Also create a new map with (key=statecode , value=statename) and marge with the above map
//		- also delete the key(5)
//		- check if the map is empty or not
//		- clear the map
	
	public static void main(String[] args) {
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(1, "India");
		mp.put(2, "USA");
		mp.put(3, "Canada");
		mp.put(4, "Australia");
		mp.put(5, "Japan");
		mp.put(6, "Germany");
		mp.put(7, "UAE");
		mp.put(8, "Saudai Arabia");
		mp.put(9, "Russia");
		mp.put(10, "Pakistan");
		
		for(Integer key:mp.keySet()) {
			System.out.println(key+":"+mp.get(key));
		}
		System.out.println("KEYS-->"+mp.keySet());
		System.out.println("Values-->"+mp.values());
		
		
		
		System.out.println("Check If Key 45 Exists-->"+mp.containsKey(45));
		System.out.println("Check If Value 'India' Exists-->"+mp.containsValue("India"));
		
		mp.remove(1);
		System.out.println("AFter Removal-->"+mp);
		
	}

}
