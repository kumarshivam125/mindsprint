package mypkg;
import java.util.*;
public class Collection1 {
	public static void main(String[] args) {
		LinkedHashSet l1=new LinkedHashSet();
		l1.add(2); 
		l1.add(20);
		l1.add(2.5f); 
		l1.add(20.0f);
		l1.add('a'); 
		l1.add('b');
		l1.add(true);
		System.out.println(l1);
		
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter 10 Numbers");
//		LinkedHashSet<Integer> l2=new LinkedHashSet<Integer>();
//		for(int i=0;i<10;i++)
//		{
//			int x=sc.nextInt();
//			l2.add(x);
//		}
//		System.out.println(l2);
		
		//ALL the elements will be in sorted order
		TreeSet ts=new TreeSet();
		ts.add("Java");
		ts.add("C++");
		ts.add("C");
		ts.add("Go");
		ts.add("Rust");
		ts.add("Python");
		System.out.println("Before Removing--"+ts);
		ts.remove("Python");
		ts.remove("C++");
		System.out.println("After Removing--"+ts);
		System.out.println("Does java Exist --"+ts.contains("Java"));
		ts.clear();
		System.out.println("After Making Empty--"+ts);
	}

}
