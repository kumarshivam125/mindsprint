package mypkg;
import java.util.*;

public class Collection3 {

//	Assignment 3:
//		Create object of ArrayList and add
//		6 fruits
//		2 cities
//		2 hobbies
//		do following operations:
//		- print the arraylist
//		- remove one hobby
//		- search("cricket")
//		- remove 1 city & remove 1 fruit
//		- print 4th & 6th element
//		- replace the hobby "Singing" with new hobby "Dancing"
//		- reverse the arraylist
//		- add "Kerala" at 4th position and add "Mango" at 2nd position
//		-fetch the substring from index 2 to 5 and print it 
	public static void main(String[] args) {
		ArrayList<String> arr=new ArrayList<String>();
		arr.add("f1"); 
		arr.add("f2");
		arr.add("f3");
		arr.add("f4");
		arr.add("f5");
		arr.add("f6");
		
		arr.add("c1");
		arr.add("c2");

		arr.add("h1");
		arr.add("h2");
		
		System.out.println(arr);
		System.out.println(arr.contains("cricket"));
		arr.remove("c1");
		arr.remove("f1");
		
		int ind=arr.indexOf("Singing");
		if(ind!=-1)
			arr.set(ind, "Dancing");
		
		System.out.println("After Updating the HOBBY-"+arr);
		
		System.out.println("SubList-"+arr.subList(2, 5));
		
	}

}
