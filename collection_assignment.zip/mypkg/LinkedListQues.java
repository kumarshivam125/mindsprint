package mypkg;
import java.util.*;

//Assignment 4:
//Use LinkedList only in the below program
//   - Add 6 months (May, June, July, August, April, November)
//   - Add 'December' month as last
//   - Add 'January' month as first
//   - Add 'March' and then add 'Febuary' using the index based 
//   - Add 'September' and then add 'October' using the index based
// 
//(1) Print the linkedlist in such a way that proper order of months are displayed
//(2) Get all the even months and print them 
//(3) Get all the odd months and print them
//(4) Use iterator to fetch and print all months 
//(5) Print the first and last month of the year together
//(6) remove your birthday month from the linkedList and print it
//(7) Check whether this linkedList contains any winter month inside it or not?
//(8) Fetch the first and last months using peek()
//(9) Remove the first and last months using poll()

public class LinkedListQues {
	public static void main(String[] args) {
        LinkedList<String> ll = new LinkedList<String>();
        ll.add("May");
        ll.add("June");
        ll.add("July");
        ll.add("August");
        ll.add("April");
        ll.add("November");
        ll.addLast("December");
        ll.addFirst("January");
        ll.add(1,  "Febuary");
        ll.add(2,  "March");
        ll.remove("April");
        ll.add(3,  "April");
        ll.add(8,  "September");
        ll.add(9,  "October");
        System.out.println(ll);
        
        
        System.out.print("Even Months--->");
        for(int i=0;i<ll.size();i++) {
        	if((i+1)%2==0)
        		System.out.print(ll.get(i)+" ");
        }
        
        System.out.print("\nOdd Months--->");
        for(int i=0;i<ll.size();i++) {
        	if((i+1)%2==1)
        		System.out.print(ll.get(i)+" ");
        }
        System.out.println("\n------------Using Iterator----------");
        Iterator it=ll.iterator();
        while(it.hasNext())
        	System.out.print(it.next()+" ");
        
        System.out.print("\nFirst and Last Month--->");
        System.out.println(ll.peekFirst() +" "+ ll.peekLast());
        
        if(ll.contains("November") || ll.contains("December") )
        	System.out.println("Contains Winter Month");
        else
        	System.out.println("Contains Winter Month");
	}

}
