package mypkg;
import java.util.*;

public class HashSet1 {

	public static void main(String[] args) {
		HashSet hs = new HashSet();
		hs.add(340);
		hs.add(true);
		hs.add('H');
		hs.add(560.00f);
		hs.add(5000.00);
		hs.add("India");
		hs.add(new String("Java"));
		System.out.println(" the hashset is " + hs);
		System.out.println(hs.contains("India"));
		System.out.println(hs.remove(340));
		System.out.println(" the hashset is " + hs);
		System.out.println();
		System.out.println(hs.size());
		System.out.println(hs.isEmpty());
	    hs.clear();
		System.out.println(" the hashset is " + hs);
		
		System.out.println("-------------------------------------------");
		HashSet<String> hsnew = new HashSet<String>();
		hsnew.add("India");
		hsnew.add(new String("Java"));
		hsnew.add("Sri Lanka");
		hsnew.add("Europe");
		hsnew.add("Austriaia");
		hsnew.add("HTML");
		hsnew.add("Python");
		System.out.println(" the hashset is " + hsnew);
		
		System.out.println("-------------------------------------------");

		LinkedHashSet<String> hsnew1 = new LinkedHashSet<String>(); hsnew.add("India");
		hsnew1.add(new String("Java"));
		hsnew1.add("Sri Lanka");
		hsnew1.add("Europe");
		hsnew1.add("Austriaia");
		hsnew1.add("HTML");
		hsnew1.add("Python");
		System.out.println(" the hashset is " + hsnew1);
		hsnew1.addAll(hs);
		System.out.println(" the hashset is " + hsnew1);
		
		
		
	}
}
