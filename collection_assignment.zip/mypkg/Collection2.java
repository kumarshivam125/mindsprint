package mypkg;
import java.util.*;

public class Collection2 {
	public static void main(String args[]) {
		ArrayList<String> arr=new ArrayList<String>();  
		System.out.println("Initiarr size of Arraylist is "+ arr.size());  // SIZE OF ARRAYLIST
		arr.add("Hai");
		arr.add("Hello");
		arr.add("Hai");
		arr.add("Come On");
		arr.add("Eat the food");
		arr.add("Take rest");
		System.out.println("Arraylist is "+arr.size()+arr);
		arr.add(1,"How are you");
		System.out.println("New Arraylist is "+arr.size() +arr);
		System.out.println("-------------------------");
		
		System.out.println("element at position 1 is  : "+ arr.get(1)); 
		Collections.reverse(arr);   
		System.out.println("Reversed arraylist is : "+ arr);    
		arr.set(2, "Bye"); //Setting Bye - Bye at position 6 (or) Replacing Hello by Bye at position 2
        System.out.println("After setting/replacing element at ind 2 is : " + arr);
        arr.remove(2);
        System.out.println("New Arraylist is "+arr);
        System.out.println(arr.indexOf("Hai"));
        
        System.out.println("-------------------------");
        arr.remove("Hello");
        System.out.println("New Arraylist is "+arr);
        System.out.println(arr.contains("Hello"));      
        arr.remove(1);
        System.out.println("New Arraylist is "+arr);
        System.out.println(arr.subList(2, 4));

	}
}
